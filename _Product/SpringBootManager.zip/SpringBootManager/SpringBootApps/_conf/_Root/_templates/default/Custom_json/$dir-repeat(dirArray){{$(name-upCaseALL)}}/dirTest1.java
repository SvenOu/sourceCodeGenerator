name: ${{name}}

namet: ${{namet}}

dirArray2: ${{dirArray2}}

