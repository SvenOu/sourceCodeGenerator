${{attr1-lowerCaseFirst}}
${{attr2-upCaseFirst}}
$tp-repeat(test.t1.t2.fieldsValues-suffix~***){{private $(fieldAttr1) $(fieldAttr2-upCaseALL);
}}
