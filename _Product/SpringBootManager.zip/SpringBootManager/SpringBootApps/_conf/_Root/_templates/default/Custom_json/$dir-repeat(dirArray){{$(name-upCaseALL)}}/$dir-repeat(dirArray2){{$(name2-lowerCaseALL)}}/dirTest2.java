name2: ${{name2}}

#root.dirName2-upCaseFirst:    ${{#root.dirName2-upCaseFirst}}