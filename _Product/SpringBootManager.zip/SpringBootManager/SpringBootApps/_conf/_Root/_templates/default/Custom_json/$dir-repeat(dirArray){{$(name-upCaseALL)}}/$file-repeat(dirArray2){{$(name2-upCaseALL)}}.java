${{name2-upCaseFirst}}

${{#root.dirName1-upCaseFirst}}

$tp-repeat(#root.testObject.a.b.testArray){{
/***********************************************/
title:     $(title)
name:     $(name)
/***********************************************/
}}